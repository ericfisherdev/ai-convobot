# AI Companion - CPU Build

## About
This is a release build of AI Companion with CPU acceleration support.

## System Requirements
- Operating System: Windows
- Architecture: x86_64-pc-windows-gnu
- Acceleration: CPU

### Additional Requirements for CPU builds:
- No additional GPU requirements
- Runs on CPU only

## Usage
1. Extract the package to a directory of your choice
2. Run the executable: `ai-companion.exe`
3. Open your browser to `http://localhost:3000`
4. Configure your LLM model path in the settings
5. Start chatting with your AI companion!

## Configuration
- The application will create a `companion_database.db` file in the current directory
- Default port is 3000 (configurable in the application)
- LLM models must be in GGUF format

## Support
For issues and documentation, visit: https://github.com/ericfisherdev/ai-convobot